package util;

import java.io.IOException;
import java.util.Map;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletFilter implements Filter {
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("init call");
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		
		// char encoding utf8
		// üğşçöÜĞİŞÇÖ
		req.setCharacterEncoding("UTF8");
		res.setCharacterEncoding("UTF8");
		
		// Parameter pull
		Map<String, String[]>  hm = req.getParameterMap();
		Set<String> keys = hm.keySet();
		for( String key : keys ) {
			String val = hm.get(key)[0];
			System.out.println("key : " + key + " val : " + val );
			boolean stStatu = fncErrorString(val);
			if (stStatu) {
				System.out.println("Yasaklı kelime girdiniz!");
			}
		}
		
		// get ip address
		String ip = req.getRemoteAddr();
		System.out.println("ip Address : " + ip);
		
		chain.doFilter(req, res);
		
	}
	
	
	public boolean fncErrorString( String data ) {
		boolean statu = false;
		String arr[] = { "ist", "bir", "kırmızı", "iki" };
		for( String item : arr ) {
			if ( item.equals(data) ) {
				statu = true;
				break;
			}
		}

		return statu;
	}
	

	
	@Override
	public void destroy() {
		System.out.println("destroy call");
	}
	
}
