package user;

public class UserLogin {
	
	public boolean fncUserLogin( String mail, String  pass ) {
		System.out.println("mail : " + mail + " Pass : " + pass);
		if (mail.equals("ali@ali.com")  && pass.equals("12345") ) {
			return true;
		}
		return false;
	}

}
