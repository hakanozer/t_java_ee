package com.works.twodays.util;

import javax.servlet.http.HttpServletRequest;

public class Util {

	public static String control( String page, HttpServletRequest req ) {
		boolean statu = req.getSession().getAttribute("uid") != null;
		if (statu) {
			return page;
		}
		return "redirect:/";
	}
	
	
}
