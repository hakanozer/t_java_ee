package com.works.twodays.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class UserModel {

	public boolean fncUserLogin( DriverManagerDataSource db, String email, String pass, HttpServletRequest req ) {
		boolean statu = false;
		try {
			String query = "select * from user where umail = ? and upass = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			pre.setString(1, email);
			pre.setString(2, pass);
			ResultSet rs = pre.executeQuery();
			statu = rs.next();
			if (statu) {
				// session create
				req.getSession().setAttribute("uid", rs.getInt("uid"));
				req.getSession().setAttribute("uname", rs.getString("uname"));
			}
		} catch (Exception e) {
			System.err.println("Login Error : " + e);
		}
		return statu;
	}
	
	
	public int fncUserInsert( DriverManagerDataSource db, UserPro us ) {
		int row = 0;
		try {
			String query = "insert into user(uname, umail, upass) values ( ?, ?, ?)";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			pre.setString(1, us.getUname());
			pre.setString(2, us.getUmail());
			pre.setString(3, us.getUpass());
			row = pre.executeUpdate();
		} catch (Exception e) {
			System.err.println("Insert Error : " + e);
		}
		return row;
	}
	
	
	public List<UserPro> allUser( DriverManagerDataSource db ) {
		List<UserPro> ls = new ArrayList<>();
		
		try {
			String query = "select * from user";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			ResultSet rs = pre.executeQuery();
			while(rs.next()) {
				UserPro us = new UserPro();
				us.setUid(rs.getInt("uid"));
				us.setUname(rs.getString("uname"));
				us.setUmail(rs.getString("umail"));
				ls.add(us);
			}
			
		} catch (Exception e) {
			System.err.println("select error : " + e);
		}
		return ls;
	}
	
	
	public int fncUserDelete( DriverManagerDataSource db, int uid ) {
		int row = 0;
		try {
			String query = "delete from user where uid = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			pre.setInt(1, uid);
			row = pre.executeUpdate();
		} catch (Exception e) {
			System.err.println("delete error : " + e);
		}
		return row;
	}
	
	
	
}
