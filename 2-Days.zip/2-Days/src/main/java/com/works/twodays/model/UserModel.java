package com.works.twodays.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;

import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class UserModel {

	public boolean fncUserLogin( DriverManagerDataSource db, String email, String pass, HttpServletRequest req ) {
		boolean statu = false;
		try {
			String query = "select * from user where umail = ? and upass = ?";
			PreparedStatement pre = db.getConnection().prepareStatement(query);
			pre.setString(1, email);
			pre.setString(2, pass);
			ResultSet rs = pre.executeQuery();
			statu = rs.next();
			if (statu) {
				// session create
				req.getSession().setAttribute("uid", rs.getInt("uid"));
				req.getSession().setAttribute("uname", rs.getString("uname"));
			}
		} catch (Exception e) {
			System.err.println("Login Error : " + e);
		}
		return statu;
	}
	
	
	public int fncUserInsert( DriverManagerDataSource db, UserPro us ) {
		int row = 0;
		try {
			String query = "insert into user values ( null, ?, ?, ?)  ";
			
		} catch (Exception e) {
			System.err.println("Insert Error : " + e);
		}
		return row;
	}
	
	
	
	
	
}
