package com.works.twodays.controllers;

import java.util.Random;
import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.works.twodays.util.Util;

@Controller
public class DashboardController {
	
	@GetMapping("/dashboard")
	public String dashboard( Model model, HttpServletRequest req, Random rd ) {
		model.addAttribute("data", "ali bilmem");
		return Util.control("dashboard", req);
	}

}
