package com.works.twodays.controllers;

import java.util.Random;
import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.works.twodays.model.UserModel;
import com.works.twodays.model.UserPro;
import com.works.twodays.util.Util;

@Controller
public class DashboardController {
	
	@Autowired DriverManagerDataSource db;
	UserModel model = new UserModel();
	
	
	@GetMapping("/dashboard")
	public String dashboard( Model model, HttpServletRequest req, Random rd ) {
		model.addAttribute("data", "ali bilmem");
		return Util.control("dashboard", req);
	}
	
	
	// user insert
	@PostMapping("/userInsert")
	public String userInsert( UserPro us ) {
		System.out.println(us.getUmail() + " " + us.getUname() + " " + us.getUpass() );
		return "redirect:/dashboard";
	}
	
	
	
	

}
