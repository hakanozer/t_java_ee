package com.works.twodays.controllers;

import java.util.List;
import java.util.Random;
import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.works.twodays.model.UserModel;
import com.works.twodays.model.UserPro;
import com.works.twodays.util.Util;

@Controller
public class DashboardController {
	
	@Autowired DriverManagerDataSource db;
	UserModel model = new UserModel();
	String error = "";
	
	public DashboardController() {
		System.out.println("DashboardController call");
	}
	
	
	@GetMapping("/dashboard")
	public String dashboard( Model modelx, HttpServletRequest req, Random rd ) {
		List<UserPro> ls = model.allUser(db);
		//System.out.println("Size : " + ls.size());
		modelx.addAttribute("error", error);
		modelx.addAttribute("ls", ls);
		error = "";
		return Util.control("dashboard", req);
	}
	
	
	// user insert
	@PostMapping("/userInsert")
	public String userInsert( UserPro us ) {
		//System.out.println(us.getUmail() + " " + us.getUname() + " " + us.getUpass() );
		model.fncUserInsert(db, us);
		return "redirect:/dashboard";
	}
	
	
	// user delete
	@GetMapping("/userDelete/{uid}")
	public String userDelete( @PathVariable int uid, HttpServletRequest req ) {
		int suid = (int) req.getSession().getAttribute("uid");
		if (suid == uid) {
			error = "Kişi kendisini silemez!";
			return "redirect:/dashboard";
		}else {
			model.fncUserDelete(db, uid);
		}
		
		//System.out.println("uid : " + uid);
		return "redirect:/dashboard";
	}
	
	
	

}
