package com.works.twodays.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.works.twodays.model.UserModel;


@Controller
public class LoginController {
	
	@Autowired DriverManagerDataSource db;
	UserModel model = new UserModel();
	
	
	@GetMapping({ "", "/home" })
	public String login() {
		return "login";
	}
	
	
	
	@PostMapping("/userLogin")
	public String userLogin( @RequestParam String email, @RequestParam String pass, HttpServletRequest req ) {
		boolean statu = model.fncUserLogin(db, email, pass, req);
		if (statu) {
			return "redirect:/dashboard";
		}
		return "login";
	}
	
	
	// user exit
	@GetMapping("/exit")
	public String exit( HttpServletRequest req ) {
		// single session remove
		req.getSession().removeAttribute("uid");
		// all session remove
		req.getSession().invalidate();
		return "redirect:/";
	}

}
