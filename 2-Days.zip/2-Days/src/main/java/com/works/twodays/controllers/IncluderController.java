package com.works.twodays.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IncluderController {
	
	@GetMapping("/menu")
	public String menu( HttpServletRequest req, Model model ) {
		
		String uname = ""+ req.getSession().getAttribute("uname");
		model.addAttribute("uname", uname);
		return "inc/menu";
		
	}

}
