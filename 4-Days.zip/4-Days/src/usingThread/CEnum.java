package usingThread;

public enum CEnum {
	Currency, CurrencyName, ForexBuying, ForexSelling
}
