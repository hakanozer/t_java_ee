package usingThread;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.parser.Parser;
import org.jsoup.select.Elements;

public class XUtil {
	
	public XUtil() {
		call();
		Timer timer = new Timer();
		timer.schedule(task, 1000, 3000);
	}
	
	TimerTask task = new TimerTask() {
		@Override
		public void run() {
			
			try {
				String url = "https://www.tcmb.gov.tr/kurlar/today.xml";
				String data = Jsoup.connect(url).get().toString();
				Document doc = Jsoup.parse(data,"", Parser.xmlParser());
				Elements elements = doc.getElementsByTag(""+CEnum.Currency);
				for(Element item : elements) {
					String CurrencyName = item.getElementsByTag(""+CEnum.CurrencyName).text();
					String ForexBuying = item.getElementsByTag(""+CEnum.ForexBuying).text();
					String ForexSelling = item.getElementsByTag(""+CEnum.ForexSelling).text();
					System.out.println(CurrencyName + " " + ForexBuying + " " + ForexSelling);
				}
			} catch (Exception e) {
				System.err.println("Xml Read Error : " + e);
			}
			
		}
	};
	
	
	static String data = "";
	private void call() {
		
		Action aca = new Action("A");
		Thread th1 = new Thread(aca);
		th1.start();
		
		Action acb = new Action("B");
		Thread th2 = new Thread(acb);
		th2.start();
		
		
		// java 8 Lambda -> thread using
		Runnable rn = () -> {
			try {
				String url = "http://jsonbulut.com/json/companyCategory.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24";
				data = Jsoup.connect(url).timeout(30000).ignoreContentType(true).get().body().text();
			} catch (Exception e) {
				System.err.println("category error : " + e);
			}
			
		};
		new Thread(rn).start();
		//fncListener();
		System.out.println("fnc Call");
		
	}
	
	private void fncListener() {
		while(true) {
			if (!XUtil.data.equals("")) {
				break;
			}
		}
		System.out.println("pull data : " + data);
	}
	

}
