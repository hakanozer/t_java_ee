package usingThread;

public class Action implements Runnable {
	
	String data = "";
	public Action( String data ) {
		this.data = data;
	}

	@Override
	public void run() {
		
		boolean statu = false;
		for(;;) {
			if(statu) break;
			System.out.println("Thread Call : " + data);
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				
			}
		}
	}

}
