package appPack;

import org.jsoup.Jsoup;
import com.google.gson.Gson;

public class RestProduct {

	public RestProduct() {
		restResult();
	}
	
	
	private void restResult() {
		System.out.println("restResult call");
	}
	
	
}
