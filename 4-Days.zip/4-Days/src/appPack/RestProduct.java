package appPack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.jsoup.Jsoup;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import model.Bilgiler;
import model.JsonData;

public class RestProduct {
	
	public static List<Bilgiler> ls = new ArrayList<Bilgiler>();

	public RestProduct() {
		restResult();
	}
	
	
	private void restResult() {
		long  start = System.currentTimeMillis();
		ls.clear();
		try {
			HashMap<String, String> hm = new HashMap<>();
			hm.put("ref", "5380f5dbcc3b1021f93ab24c3a1aac24");
			hm.put("start", "0");
			String url = "http://jsonbulut.com/json/product.php";
			
			// jsoup -> rest
			String data = Jsoup.connect(url).data(hm).timeout(30000).ignoreContentType(true).get().body().text();
			
			Gson gson = new Gson();
			//JsonObject obj = gson.fromJson(data, JsonObject.class);
			//boolean durum = obj.getAsJsonArray("Products").get(0).getAsJsonObject().get("durum").getAsBoolean();
			//System.out.println("durum : " + durum);
			
			// Object convert
			JsonData jsonData = gson.fromJson(data, JsonData.class);
			ls = jsonData.getProducts().get(0).getBilgiler();
			//boolean durum = jsonData.getProducts().get(0).getDurum();
			//System.out.println("durum : " + durum);
			
			
		} catch (Exception e) {
			System.err.println("Services Error : " + e);
		}
		long end = System.currentTimeMillis();
		long between = end - start;
		System.out.println("Milis : " + between);
	}
	
	
}
