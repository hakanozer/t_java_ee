package com.works.fivedays;

public class App 
{
    public static void main( String[] args )
    {
       
    	try {
    		final MessageSender messageSender = new MessageSender();
    		final MessageReceiver messageReceiver = new MessageReceiver();
    		messageReceiver.listener();
    		
    		for (int i = 0; i < 100; i++) {
				messageSender.sendMessage("2021 Fenerbahçe Şampiyon " + i);
				Thread.sleep(300);
			}
    		
    		messageSender.destroy();
    		messageReceiver.destroy();
    		
		} catch (Exception e) {
			System.err.println("App error : " + e);
		}
    	
    	
    	
    }
}
