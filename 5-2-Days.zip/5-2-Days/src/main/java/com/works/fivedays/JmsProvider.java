package com.works.fivedays;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;

public class JmsProvider {
	
	public static ConnectionFactory connectionFactory () {
		ConnectionFactory factory = new ActiveMQConnectionFactory("vm://localhost");
		return factory;
	}

}
