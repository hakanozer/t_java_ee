package com.works.fivedays;

import javax.jms.*;

public class MessageSender {
	
	private  MessageProducer producer;
	private  Session session;
	private  Connection connection;
	
	
	public MessageSender() {
		try {
			
			ConnectionFactory connectionFactory = JmsProvider.connectionFactory();
			connection = connectionFactory.createConnection();
			connection.start();
			
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			Queue queue = session.createQueue("com.works.fivedays");
			producer = session.createProducer(queue);
			
		} catch (Exception e) {
			System.err.println("MessageSender Error :" + e );
		}
	}
	
	
	public void sendMessage( String message ) throws JMSException  {
		
		System.out.println("Send Message : " + message);
		TextMessage textMessage = session.createTextMessage(message);
		producer.send(textMessage);
		
	}
	
	public void destroy() throws JMSException {
		connection.close();
	}

}
