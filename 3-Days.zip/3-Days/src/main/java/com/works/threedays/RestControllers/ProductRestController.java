package com.works.threedays.RestControllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.works.threedays.model.Product;
import com.works.threedays.repositories.ProductRepository;

@RestController
public class ProductRestController {
	
	@Autowired ProductRepository prepo;
	
	@GetMapping("/allProduct")
	public Map<String, Object> allProduct() {
		Map<String, Object> hm = new LinkedHashMap<>();
		hm.put("statu", true);
		hm.put("allProduct",  prepo.findAll() );
		return hm;
	}
	
	
	
	// product insert
	@PostMapping("/productInsert")
	public Map<String, Object> productInsert( Product pr ) {
		Map<String, Object> hm = new LinkedHashMap<>();
		Product ipr = prepo.saveAndFlush(pr);
		hm.put("statu", false);
		if (ipr != null) {
			hm.put("statu", true);
			hm.put("product", ipr);
		}
		return hm;
	}
	
	
	// product insert -> json
	@PostMapping("/productInsertJson")
	public Map<String, Object> productInsertJson( @RequestBody Product pr ) {
		return productInsert(pr);
	}
	
	// product delete
	@DeleteMapping("/productDelete")
	public Map<String, Object> productDelete(int pid) {
		Map<String, Object> hm = new LinkedHashMap<>();
		try {
			prepo.deleteById(pid);
			hm.put("statu", true);
		} catch (Exception e) {
			hm.put("statu", false);
		}
		return hm;
	}
	
	
	
	// product single data
	@GetMapping("/productSingle")
	public Map<String, Object> productSingle(int pid) {
		Map<String, Object> hm = new LinkedHashMap<>();
		Optional<Product> pr = prepo.findById(pid);
		hm.put("statu", false);
		pr.ifPresent(item -> {
			hm.put("statu", true);
			hm.put("product", item);
		});
		return hm;
	}
	
	
	/*
	// product single data
	Product itm = null;
	@GetMapping("/productSingle")
	public ResponseEntity productSingle(int pid) {
		Map<String, Object> hm = new LinkedHashMap<>();
		Optional<Product> pr = prepo.findById(pid);
		if (!pr.isPresent()) {
			return  ResponseEntity.badRequest().build();
		}
		
		//hm.put("statu", false);
		pr.ifPresent(item -> {
			itm = item;
			//hm.put("statu", true);
			//hm.put("product", item);
		});
		return ResponseEntity.ok(itm);
	}
	*/

}
