package appPack;

import java.io.IOException;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
//@RequestScoped
@SessionScoped
public class User {
	
	private String mail;
	private String pass;
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public String send() throws IOException  {
		String r = "";
		if (mail != null && pass != null) {
			System.out.println( mail + " " + pass );
			if (mail.equals("ali@ali.com") &&  pass.equals("12345")) {
				//r = "dashboard.xhtml?faces-redirect=true";
				FacesContext.getCurrentInstance().getExternalContext().redirect("dashboard.xhtml?faces-redirect=true");
			    FacesContext.getCurrentInstance().responseComplete();
				r = "Giriş Başarılı";
			}else {
				r = "Giriş Hatalı";
			}
		}
		return r;
	}
	
}
